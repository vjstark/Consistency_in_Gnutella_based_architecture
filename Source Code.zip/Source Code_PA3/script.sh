#!/bin/bash
JAVA_HOME=/usr/bin/java/
CLASSPATH=/Users/vjstark/Documents/Consistency/GnutellaP2P_ios.jar:/Users/vjstark/Documents/Consistency/javax.ws.rs-api-2.0.jar:.
$JAVA_HOME -cp $CLASSPATH com.gfiletransfer.SuperPeer
