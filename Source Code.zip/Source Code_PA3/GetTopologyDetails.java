package com.gfiletransfer;

public class GetTopologyDetails {

	private String Peer_ID = null;
	private String All_Neighbour = null;
	private String Linear_Neighbour = null;
	
	public String getAll_Neighbour() {
		return All_Neighbour;
	}
	
	public void setAll_Neighbour(String all_Neighbour) {
		All_Neighbour = all_Neighbour;
	}
	
	public String getLinear_Neighbour() {
		return Linear_Neighbour;
	}
	
	public void setLinear_Neighbour(String linear_Neighbour) {
		Linear_Neighbour = linear_Neighbour;
	}

	public String getPeer_ID() {
		return Peer_ID;
	}

	public void setPeer_ID(String peer_ID) {
		Peer_ID = peer_ID;
	}
}

